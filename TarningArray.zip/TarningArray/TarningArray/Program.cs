﻿using System;
using System.Collections.Generic;

namespace app1;

class tarningsarray
{
    static void Main(string[] args)
    {
        Random tarningr = new Random();
        List<int> tarning = new List<int>();

        tarning.Add(1);
        tarning.Add(2);
        tarning.Add(3);
        int run = 1;
        while (run == 1)
        {

            for (int i = 0; i < tarning.Count; i++)
            {
                int x = i + 1;
                tarning[i] = tarningr.Next(1, 7);
                // gör en till for loop som plusar ihop alla tärningar
                Console.WriteLine("Tärning " + x + " blev " + tarning[i]);
                if (tarning.Count == 1)
                {
                    tarning.Add(2);
                    tarning.Add(3);
                }
                if (tarning[i] == 6)
                {
                    tarning.Add(4);
                    tarning.Add(5);
                }
                if (i == tarning.Count - 1)
                {
                    int total = tarning.Sum();
                    int total2 = tarning.Sum() + 2;
                    Console.WriteLine("Totala värdet av dina slag: " + total);
                    Console.WriteLine("Totala värdet med två adderat för uppgift: " + total2);
                    Console.WriteLine("Tryck på mellanslag för att spela igen. Tryck på en annan tangent för att avsluta.");
                    if (Console.ReadKey().Key == ConsoleKey.Spacebar)
                    {
                        total = 0;
                        total2 = 0;
                        tarning.RemoveRange(1, tarning.Count - 1);
                        Console.WriteLine("");
                        run = 1;
                    }
                    else
                    {
                        run = 2;
                    }
                }
            }
        }
        Console.WriteLine("");
        Console.WriteLine("Tack för att du spelade!");
    }
}